const productos = [
  {
    nombre: "Tomate redondo",
    precio: 3500,
    descripcion: "Tomates frescos, ideales para ensaladas y salsas.",
    imagen: "https://cdn.pixabay.com/photo/2016/03/05/19/02/tomatoes-1238257_1280.jpg"
  },
  {
    nombre: "Lechuga repollada",
    precio: 6800,
    descripcion: "Lechuga crujiente y de hojas compactas, perfecta para acompañar tus platos o hacer wraps.",
    imagen: "https://cdn.pixabay.com/photo/2013/07/18/20/26/iceberg-lettuce-164368_1280.jpg"
  },
  {
    nombre: "Lechuga hoja",
    precio: 7900,
    descripcion: "Lechuga de hojas, tiernas y sabrosas, ideal para ensaladas frescas y saludables.",
    imagen: "https://cdn.pixabay.com/photo/2016/04/28/21/34/lettuce-1369984_1280.jpg"
  }
];

const carrito = [];

function crearOpcionesCantidad() {
  return Array.from({ length: 10 }, (_, i) => `<option value="${i + 1}">${i + 1}</option>`).join("");
}

function renderProductos() {
  const contenedor = document.getElementById("productos-container");
  contenedor.innerHTML = productos.map((prod, index) => `
    <div class="producto">
      <img src="${prod.imagen}" alt="${prod.nombre}">
      <h3>${prod.nombre} – $${prod.precio}</h3>
      <p>${prod.descripcion}</p>
      <label>Presentación:
        <select id="presentacion-${index}" onchange="actualizarCantidad(${index})">
          <option value="kilo">Por kilo</option>
          <option value="unidad">Por unidad</option>
        </select>
      </label>
      <br/>
      <label>Cantidad:
        <select id="cantidad-${index}">
          <option value="">--</option>
          ${crearOpcionesCantidad()}
        </select>
      </label>
      <br/>
      <button onclick="agregarAlCarrito(${index})">Agregar</button>
    </div>
  `).join("");
}

function actualizarCantidad(index) {
  const cantidadSelect = document.getElementById(`cantidad-${index}`);
  cantidadSelect.innerHTML = '<option value="">--</option>' + crearOpcionesCantidad();
}

function agregarAlCarrito(index) {
  const producto = productos[index];
  const presentacion = document.getElementById(`presentacion-${index}`).value;
  const cantidad = document.getElementById(`cantidad-${index}`).value;

  if (!cantidad) {
    alert("Seleccioná una cantidad.");
    return;
  }

  carrito.push({ ...producto, presentacion, cantidad });
  mostrarCarrito();
}

function mostrarCarrito() {
  const contenedor = document.getElementById("carrito");
  contenedor.innerHTML = carrito.map(item =>
    `${item.cantidad} ${item.presentacion} de ${item.nombre}`
  ).join("<br>");
  actualizarWhatsApp();
}

function actualizarWhatsApp() {
  const nombre = document.getElementById("nombre").value;
  const direccion = document.getElementById("direccion").value;
  const entrega = document.getElementById("entrega").value;
  const pago = document.getElementById("pago").value;

  let mensaje = `¡Hola! Soy ${nombre} y quiero pedir:\n\n`;

  carrito.forEach(item => {
    mensaje += `- ${item.cantidad} ${item.presentacion} de ${item.nombre}\n`;
  });

  mensaje += `\nDirección: ${direccion}\nEntrega: ${entrega}\nPago: ${pago}`;

  const url = `https://wa.me/549${/* tu número */"1123456789"}?text=${encodeURIComponent(mensaje)}`;
  document.getElementById("btnEnviar").href = url;
}

document.getElementById("formulario").addEventListener("input", actualizarWhatsApp);

renderProductos();